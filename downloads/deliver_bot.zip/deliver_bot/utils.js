function getSpanishDate(timestampInSeconds) {
    const date = new Date(timestampInSeconds * 1000);

    // Options for formatting the date in Spanish
    const options = {
        year: 'numeric',
        month: 'long', // 'long' for full month name, 'short' for abbreviated
        day: 'numeric',
        weekday: 'long', // 'long' for full weekday name, 'short' for abbreviated
        timeZone: 'UTC', // Adjust according to your timezone
        timeZoneName: 'short'
    };
    return date.toLocaleDateString('es-ES', options);
}

module.exports = {getSpanishDate}
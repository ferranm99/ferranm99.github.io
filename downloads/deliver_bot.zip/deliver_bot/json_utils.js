const jsonfile = require('jsonfile');
const filePath = './data/data.json';

// Read JSON from a file
async function readJsonFile() {
    try {
        const jsonData = await jsonfile.readFile(filePath);
        return jsonData;
    } catch (error) {
        console.error('Error reading JSON file:', error);
    }
}

// Write JSON to a file
async function writeJsonFile(data) {
    try {
        await jsonfile.writeFile(filePath, data, { spaces: 2 });
        console.log('JSON file written successfully.');
    } catch (error) {
        console.error('Error writing JSON file:', error);
    }
}

// Add a new user
async function addUser(userId, subscription, custId) {
    try {
        const jsonData = await readJsonFile();
        jsonData.users.push({userId, subscription, custId});
        await writeJsonFile(jsonData);
    } catch (error) {
        console.error('Error adding user:', error);
    }
}

// Delete a user based on userId
async function deleteUser(userId) {
    try {
        let jsonData = await readJsonFile();
        jsonData.users = jsonData.users.filter(user => user.userId !== userId);
        await writeJsonFile(jsonData);
    } catch (error) {
        console.error('Error deleting user:', error);
    }
}

// Delete an array of users
async function deleteUsers(usersToDelete) {
    try {
        let jsonData = await readJsonFile();
        const userIdsToDelete = usersToDelete.map(user => user.userId);
        jsonData.users = jsonData.users.filter(user => !userIdsToDelete.includes(user.userId));
        await writeJsonFile(jsonData);
    } catch (error) {
        console.error('Error deleting users:', error);
    }
}

// Get all users as a JS array
const getAllUsers = async () => {
    try {
        const data = await readJsonFile();
        return data.users || [];
    } catch (error) {
        console.error('Error getting all users:', error);
        return [];
    }
};

// Get all admins as a JS array
const getAllAdmins = async () => {
    try {
        const data = await readJsonFile();
        return data.admins || [];
    } catch (error) {
        console.error('Error getting all users:', error);
        return [];
    }
};

// Get the active subscription
async function getActiveSubs(){
    try {
        const data = await readJsonFile();
        return data.activeProduct || "";
    } catch (error) {
        console.error('Error getting active subscription:', error);
        return "";
    }
};

async function setActiveSubs(subs_id){
    try {
        const data = await readJsonFile();
        data.activeProduct = subs_id
        await writeJsonFile(data)
    } catch (error) {
        console.error('Error setting active subscription:', error);
    }
};

// Add a new admin
async function addAdmin(admin) {
    try {
        const jsonData = await readJsonFile();
        jsonData.admins.push(admin);
        await writeJsonFile(jsonData);
    } catch (error) {
        console.error('Error adding admin:', error);
    }
}

// Add a new product
async function addProduct(product) {
    try {
        const jsonData = await readJsonFile();
        jsonData.products.push(product);
        await writeJsonFile(jsonData);
    } catch (error) {
        console.error('Error adding product:', error);
    }
}

// Edit a user's subscriptionID
async function findUserSubscription(userId) {
    try {
        let jsonData = await readJsonFile();
        const index = jsonData.users.findIndex(user => user.userId == userId);
        if (index !== -1) {
            return jsonData.users[index].subscription
        } else {
            console.error('User not found.');
        }
    } catch (error) {
        console.error('Error finding subscription:', error);
    }
    return null
}

async function findUserCustomer(userId) {
    try {
        let jsonData = await readJsonFile();
        const index = jsonData.users.findIndex(user => user.userId == userId);
        if (index !== -1) {
            return jsonData.users[index].custId
        } else {
            console.error('User not found.');
        }
    } catch (error) {
        console.error('Error finding custId:', error);
    }
    return null
}

async function findUserId(subs) {
    try {
        let jsonData = await readJsonFile();
        const index = jsonData.users.findIndex(user => user.subscription == subs);
        if (index !== -1) {
            return jsonData.users[index].userId
        } else {
            console.error('User not found.');
        }
    } catch (error) {
        console.error('Error finding userId:', error);
    }
    return null
}

module.exports = {
    addUser,
    deleteUser,
    deleteUsers,
    getAllUsers,
    addAdmin,
    addProduct,
    getAllAdmins,
    findUserSubscription,
    findUserId,
    getActiveSubs,
    setActiveSubs,
    findUserCustomer
};

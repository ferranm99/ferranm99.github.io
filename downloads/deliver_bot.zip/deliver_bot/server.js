const express = require('express');
const bodyParser = require('body-parser');
const app = express();
const BOT = require('./bot.js');
const db = require('./json_utils.js');

app.use(bodyParser.json());

// Webhook endpoint to receive Stripe events
app.post('/webhook', async (req, res) => {
    const event = req.body;

    // Handle event types as per your requirement
    switch (event.type) {
        case 'checkout.session.completed':
            const session = event.data.object;
            console.log(session)
            // Add user to the group
            db.addUser(session.metadata.userId, session.subscription, session.customer)
            BOT.sendInvite(session.metadata.userId)
            break;
        // Handle other events like subscription cancellation, etc.
        case 'customer.subscription.updated':
            const subs = event.data.object;
            console.log(subs)
            break;
        case 'customer.subscription.deleted':
            const del = event.data.object;
            db.findUserId(del.id).then((userId) => {
                if(userId != null) BOT.banUser(userId)
            })
            //console.log(del)
            break;
        default:
            console.log('Unhandled event type:', event.type);
    }

    res.status(200).end();
});

app.listen(3000, () => {
    console.log('Server is running on port 3000');
});


BOT.launch()
require('dotenv').config()
const db = require('./json_utils.js');
const stripe = require('stripe')(process.env.STRIPE_SECRET);

// Function to create a Stripe checkout session
async function createCheckoutSession(userId, priceId) {
    const session = await stripe.checkout.sessions.create({
        payment_method_types: ['card'],
        mode: 'subscription',
        line_items: [{
            price: priceId,
            quantity: 1,
        }],
        success_url: process.env.SUCCESS_URL,
        metadata: {
            userId: userId
          }
    });
    return session;
}

async function getProducts() {
    try {
        const productPriceData = await stripe.prices.list({
            expand: ['data.product'],
        });

        const activeSub = await db.getActiveSubs();

        const priceDataList = productPriceData.data.map(price => ({
            id: price.product.id,
            price_id: price.id,
            amount: price.unit_amount,
            name: price.product.name,
            active: activeSub == price.product.id,
            interval: price.recurring.interval
        }));

        return priceDataList;
    } catch (err) {
        console.error('Error:', err);
    }
}

async function getSubscriptionsEndingInFuture() {
    const subscriptions = await stripe.subscriptions.list({
        //status: 'active', // You might want to filter based on status
        current_period_end: {
            gt: Math.floor(Date.now() / 1000) // Get current timestamp in seconds
        },
        limit: 1000 // Adjust the limit as per your needs
    });

    return subscriptions.data;
}

async function getAllSubscriptions() {
    let subscriptions = [];
    let hasMore = true;
    let startingAfter = undefined;

    while (hasMore) {
        const response = await stripe.subscriptions.list({
            /*current_period_end: {
                gt: Math.floor(Date.now() / 1000) // Get current timestamp in seconds
            },
            status: 'all',*/
            limit: 100, // Adjust the limit as needed
            starting_after: startingAfter
        });

        const ids = response.data.map(subscription => subscription.id);
        subscriptions = subscriptions.concat(ids);
        hasMore = response.has_more;
        startingAfter = response.data[response.data.length - 1].id; // Set startingAfter to the last subscription ID
    }

    return subscriptions;
}

async function cancelAtPeriodEnd(subId){
    return await stripe.subscriptions.update(subId,
        {
          cancel_at_period_end: true,
        }
    )
}

async function updateProductStatus(prodId, status){
    return await stripe.products.update(prodId, { active: status })
}

async function newProduct(name, interval, amount) {
    
  return await stripe.prices.create({
    currency: 'eur',
    unit_amount: amount,
    recurring: {
      interval: interval,
    },
    product_data: {
      name: name,
    },
  });
}

async function updatePayment(custId) {
    return await stripe.billingPortal.sessions.create({
        customer: custId,
        return_url: process.env.SUCCESS_URL,
        flow_data: {
            type: 'payment_method_update',
        },
    });
}


module.exports = { 
    createCheckoutSession, 
    getAllSubscriptions, 
    cancelAtPeriodEnd,
    getProducts,
    updateProductStatus,
    newProduct,
    updatePayment
}
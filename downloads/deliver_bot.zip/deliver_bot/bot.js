const { Telegraf } = require('telegraf')
const {Keyboard,Key} = require('telegram-keyboard')
require('dotenv').config()
const stripe = require('./stripe_utils.js');
const db = require('./json_utils.js');
const utils = require('./utils.js');

const bot = new Telegraf(process.env.BOT_TOKEN) 
const admins = []
const userStates = {}
const newPlan = {
  name: "",
  amount: 0,
  interval: ""
}

const translations = {
  day: "día",
  month: "mes",
  year: "año",
  week: "semana"
};


bot.use(Telegraf.log())

bot.command('start', (ctx) => {
  if(ctx.message.chat.type != 'private') {ctx.deleteMessage(); return}
  ctx.reply('¡Hola! Bienvenido/a al bot de Antonio G que te ayudará a formalizar tu subscripción en Origen '+
            'Pulsa /subscribe para suscribirte y /cancel para cancelar tu subscripción')
})

bot.command('admin', (ctx) => {
  if(ctx.message.chat.type != 'private') {ctx.deleteMessage(); return}
	let msg = (admins.includes(ctx.message.from.id))? 
		'Comandos admin:\n/nuevoAdmin\n/planes\n/nuevoPlan': 
		'Lo siento, debes ser administrador para realizar esta operación'
	ctx.reply(msg)
})

bot.command('update', async (ctx) => {
  if(ctx.message.chat.type != 'private') {ctx.deleteMessage(); return}
	let custId = await db.findUserCustomer(ctx.message.chat.id)
  if(!custId){
    ctx.reply("Actualmente no dispones de una subscripción, por lo que no puedes"
      + " realizar esta opeación. Pulsa /subscribe para suscribirte")
    return
  }
  try {
    console.log(custId)
    const session = await stripe.updatePayment(custId)
    let keyboard = Keyboard.make([Key.url('ACTUALIZAR PAGO 💳', session.url)]).inline()
    ctx.reply('Actualiza el método de pago pulsando en este botón', keyboard)
  } catch (error) {
    console.error(error)
    ctx.reply('Hubo un error, no se pudo completar la operación')
  }
})

bot.command('nuevoPlan', (ctx) => {
	if(admins.includes(ctx.message.chat.id)){
		ctx.reply('Perfecto, creemos un nuevo plan. Indícame el nombre del nuevo plan a continuación.'+
    "También puedes escribir 'cancelar' en cualquier momento para terminar la operación.")
		userStates[ctx.message.chat.id] = "planName"
	}else{
		ctx.reply('Lo siento, debes ser administrador para realizar esta operación')
	}		
})

bot.command('nuevoAdmin', (ctx) => {
	if(admins.includes(ctx.message.chat.id)){
		ctx.reply('Indicame el Id de usuario del nuevo admin. Contacta a @getmyid_bot para ello.')
		userStates[ctx.message.chat.id] = "addAdmin"
	}else{
		ctx.reply('Lo siento, debes ser administrador para realizar esta operación')
	}		
})

bot.command('planes', async (ctx) => {
	if(!admins.includes(ctx.message.chat.id)){
		ctx.reply('Lo siento, debes ser administrador para realizar esta operación')
    return
	}
  let msg = await ctx.reply('⌛')
  await printProductsAndStatus(ctx)
  ctx.deleteMessage(msg.message_id)
})

bot.action(/prod_([a-zA-Z0-9]+)/, async (ctx) => {
  await db.setActiveSubs(ctx.callbackQuery.data)
  await printProductsAndStatus(ctx)
  ctx.answerCbQuery();
});

bot.action('✅ Sí', (ctx) => {
  try {
    cancelSubscription(ctx.callbackQuery.from.id, ctx);
  } catch (error) {
    console.error(e)
    ctx.reply('Hubo un error, no se pudo completar la operación')
  }
  ctx.answerCbQuery()
});

bot.action('❌ No', (ctx) => {
  ctx.reply("Operación cancelada. Sigues suscrito a Origen.");
  ctx.answerCbQuery()
});

bot.action(/\b(?:day|month|year|week)\b/, (ctx) => {
  newPlan.interval = ctx.callbackQuery.data
  //console.log(ctx.callbackQuery.data)
  userStates[ctx.callbackQuery.from.id] = "planPrice"
  ctx.reply("Genial, solo faltaría añadir el precio en EUR. Utiliza un punto (.) para decimales");
  ctx.answerCbQuery()
});

bot.action(/^price_[a-zA-Z0-9]+$/, async (ctx) => {
  try {
    const session = await stripe.createCheckoutSession(ctx.callbackQuery.from.id, ctx.callbackQuery.data)
    let keyboard = Keyboard.make([Key.url('REALIZAR PAGO 💳', session.url)]).inline()
    ctx.reply('Completa el pago pulsando en este botón', keyboard)
  } catch (error) {
    console.error(error)
    ctx.reply('Hubo un error, no se pudo completar la operación')
  }
  ctx.answerCbQuery()
});

bot.command('subscribe', async (ctx) => {
  if(ctx.message.chat.type != 'private') {ctx.deleteMessage(); return}
  //check if active subsription first, if so, suggest /cancel command
  const userId = ctx.from.id;
  const subs = await db.findUserSubscription(userId)

  if(subs != null){
    ctx.reply("Ya tienes una subscripción activa. Si quieres cancelarla, pulsa /cancel")
    return
  }
  let msg = await ctx.reply('⌛')
  try {
      const products = await stripe.getProducts()
      let keyboardButtons = products.filter(prod => prod.active).map(prod => {
        let int = translations[prod.interval] || prod.interval;
        return [Key.callback(`${prod.name}, ${prod.amount/100} EUR/${int}`, prod.price_id)]
      });

      //const session = await stripe.createCheckoutSession(userId);
      ctx.reply("Perfecto, empecemos una nueva subscripción. Elige una de las siguientes subscripciones disponibles:",
          Keyboard.make(keyboardButtons).inline());
  } catch (error) {
      console.error('Error creating checkout session:', error);
      ctx.reply('Hubo un error intentando acceder a la subscripción.');
  }
  ctx.deleteMessage(msg.message_id)
});

bot.command('cancel', async (ctx) => {
  if(ctx.message.chat.type != 'private') {ctx.deleteMessage(); return}
  const userId = ctx.from.id;
  const subs = await db.findUserSubscription(userId)

  if(subs == null){
    ctx.reply("Todavía no tienes una subscripción. Pulsa /subscribe para crear una.")
    return
  }
  const keyboard = Keyboard.make(['✅ Sí', '❌ No'])
  ctx.reply("¿Seguro que quieres cancelar la subscripción?", keyboard.inline())
});


bot.on(['message'], async (ctx) => {
  if(ctx.message.new_chat_member || ctx.message.left_chat_member){
    ctx.deleteMessage(ctx.message.message_id)
    return
  }
  if(userStates[ctx.message.chat.id] == null || ctx.message.chat.type != 'private') 
    return
	if (ctx.message.text != null && ctx.message.text.toLowerCase() == 'cancelar'){
		ctx.reply('Operación cancelada')
		delete userStates[ctx.message.chat.id]
		return
	}

  if(userStates[ctx.message.chat.id] == "addAdmin"){
    try{
      if(parseInt(ctx.message.text)){
        await db.addAdmin(parseInt(ctx.message.text));
        ctx.reply('Administrador añadido')
        loadAdmins()
        delete userStates[ctx.message.chat.id]
      }
      else ctx.reply("Valor incorrecto, prueba con otro o escribe 'cancelar' para terminar la operación.")	

    }catch(e){
      ctx.reply('Hubo un error. Ten en cuenta que no puedes agregar un administrador 2 veces')	
    }
  }else if (userStates[ctx.message.chat.id] == "planName") {
    newPlan.name = ctx.message.text
    userStates[ctx.message.chat.id] = "planInterval"
    let buttons = [
      [Key.callback("Diario", "day"), Key.callback("Semanal", "week")],
      [Key.callback("Mensual", "month"), Key.callback("Anual", "year")]
    ]
    ctx.reply("Nombre añadido correctamente. Ahora elige el plazo de la recurrencia.", Keyboard.make(buttons).inline())
  
  }else if (userStates[ctx.message.chat.id] == "planPrice") {
    if(isNaN(parseFloat(ctx.message.text))){
      ctx.reply('Precio inválido. Prueba con otro por favor')
      return;				
    }
    try {
      newPlan.amount = Math.floor(parseFloat(ctx.message.text)*100)
      await stripe.newProduct(newPlan.name, newPlan.interval, newPlan.amount)      
      ctx.reply('Perfecto, nuevo plan creado')
    } catch (error) {
      ctx.reply('Hubo un error inesperado, vuelve a empezar con /nuevoPlan')
      console.error(error)
    }
    delete userStates[ctx.message.chat.id]
  }

})

async function printProductsAndStatus(ctx){
  try {
    const products = await stripe.getProducts()
    let keyboardButtons = products.map(prod => {
      let active = prod.active ? '✅' : '❌'
      let int = translations[prod.interval] || prod.interval;
      return [Key.callback(`${prod.name}, ${prod.amount/100} EUR/${int} ${active}`, prod.id)]
    });

    ctx.reply('A continuación verás los distintos planes. Pulsa en cualquier plan para cambiar su estado de'
      +' activo (✅) a inactivo (❌). Los usuarios solo verán los planes activos',
      Keyboard.make(keyboardButtons).inline())
  } catch (error) {
    ctx.reply("Hubo un error obteniendo los productos")
  }  
}


async function cancelSubscription(userId, ctx){
  const subs = await db.findUserSubscription(userId)
  if(subs == null){
    ctx.reply('Hubo un error al tratar de cancelar tu subscripción. Ponte en contacto con los administradores')
    return
  }
  try {
    const subupdate = await stripe.cancelAtPeriodEnd(subs)
    const date = utils.getSpanishDate(subupdate.cancel_at)
    ctx.reply(`Subscripción cancelada con éxito. Serás expulsado/a del grupo en la fecha: ${date}`)    
  } catch (error) {
    console.error(error);
  }
}

function launch(){
  console.log("bot has been launched")
  bot.launch()
  checkSubs()
  loadAdmins()
  setInterval(checkSubs, 1000 *60*60); //1000 *60*60
}

async function sendInvite(userId){
  try {
    const inviteLink = await bot.telegram.createChatInviteLink(process.env.GROUP_ID, {
      member_limit: 1, // Can only be used once
    });

    const inviteLinkCommunity = await bot.telegram.createChatInviteLink(process.env.COMUNIDAD_ID, {
      member_limit: 1, // Can only be used once
    });
    
    let keyboard = Keyboard.make(
      [
        Key.url('ORIGEN AUDIOS 🎧', inviteLink.invite_link),
        Key.url('COMUNIDAD ORIGEN 🌐', inviteLinkCommunity.invite_link)
      ]).inline()

    bot.telegram.sendMessage(userId, 'Accede a Origen con estos botones', keyboard)

  } catch (error) {
    console.error(error);
  }
}

function banUser(userId){
  bot.telegram.banChatMember(process.env.GROUP_ID, userId)
  bot.telegram.banChatMember(process.env.COMUNIDAD_ID, userId)
  db.deleteUser(userId)
}


/*setinterval to:
1) get all active subscriptions (current_period_end > now)
2) iterate through users.json list
3) if user from users.json is not in subscriptions ->ban user

*/
async function checkSubs(){
  try {
    const activeSubs =  await stripe.getAllSubscriptions()
    const users = await db.getAllUsers()
    const inactiveUsers = users.filter(
      user => !activeSubs.some(sub => sub === user.subscription)) || [];

    console.log(activeSubs)
    inactiveUsers.forEach(user => {
      banUser(user.userId)
    });
    db.deleteUsers(inactiveUsers)
  } catch (error) {
    console.error(error);
  }
}

async function loadAdmins(){
	const db_admins = await db.getAllAdmins()
	for (let a of db_admins){
		if(!admins.includes(a)) admins.push(a)
	}
}


module.exports = { launch, sendInvite, banUser }